import java.lang.Math;
import java.util.Scanner;
import java.util.Map;
import java.util.TreeMap;
public class Class_1 {

    public static void main(String[] args) {
        Scanner obj = new Scanner(System.in);

        // Take first and last x values
        System.out.println("Enter lower x limit then higher x limit");
        double lowx = obj.nextDouble();
        double highx = obj.nextDouble();
        System.out.println("Low x:" + lowx + ",High x:" + highx);

        // take x direction offset distance of each plane from x
        System.out.println("Enter distance of each plane offset in x direction starting from x lower limit");
        double offsetx = obj.nextDouble();
        System.out.println("Offset amount:" + offsetx);

        // take x value of function intersection
        //System.out.println("Enter the x value of the function intersection");
        //double interseptx = obj.nextDouble();
        //System.out.println("x value of function intersection:"+interseptx);


        // make dictionary of x and y values
        Map<String, String> m = new TreeMap<>();


        double xval = lowx;

        //for loop to index through x values if x<highx
        for (double i = lowx; i < highx; i += offsetx)
        {

            if ((lowx <= xval) && (xval <= 2.0341)) {
                double yval = (Math.pow(xval, .25)) / 2;

                String sxval = Double.toString(xval);
                String syval = Double.toString(yval);
                m.put(sxval, syval);

                xval += offsetx;
            }
            else if ((2.0341 < xval) && (xval <= highx)) {
                double yval = ((Math.cos((2 * xval) + 2)) / 8) + .475;

                String sxval = Double.toString(xval);
                String syval = Double.toString(yval);
                m.put(sxval, syval);

                xval += offsetx;
            }


        }

            System.out.println("x plane values and corresponding y values:");
            for (Map.Entry<String, String> entry : m.entrySet()) {
                String key = entry.getKey();
                String element = entry.getValue();
                System.out.println(key + "," + element);
            }

    }

}
